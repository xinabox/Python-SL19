[![GitHub Issues](https://img.shields.io/github/issues/xinabox/Python-SL19.svg)](https://github.com/xinabox/Python-SL19/issues) 
![GitHub Commit](https://img.shields.io/github/last-commit/xinabox/Python-SL19) 
![Maintained](https://img.shields.io/maintenance/yes/2020) 
![Build status badge](https://github.com/xinabox/Python-SL19/workflows/Python/badge.svg)
![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)

# Python-SL19
Infrared object temperature sensor
